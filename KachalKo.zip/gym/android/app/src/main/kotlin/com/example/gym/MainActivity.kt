package com.example.KachalKo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
