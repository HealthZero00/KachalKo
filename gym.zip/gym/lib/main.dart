import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hive_flutter/adapters.dart';
import 'package:provider/provider.dart';
import 'package:gym/models/note_data.dart';
import 'package:gym/pages/notes.dart';
import 'package:gym/routes/routes.dart';

void main() async {

  await Hive.initFlutter();
  
  await Hive.openBox("note_database1");

  runApp(
    ChangeNotifierProvider(
      create: (context) => NoteData(),
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      initialRoute: AppPage.getNavbar(),
      debugShowCheckedModeBanner: false,
      getPages: AppPage.routes,
    );
  }
}
