import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:gym/models/note.dart';
import 'package:gym/pages/editingnotepage.dart';
import 'package:provider/provider.dart';
import 'package:gym/models/note_data.dart';

class Notes extends StatefulWidget {
  @override
  State<Notes> createState() => _NotesState();
}

class _NotesState extends State<Notes> {
  @override
  void initState() {
    super.initState();
    Provider.of<NoteData>(context, listen: false).initializeNotes();
  }

  void createNewNote() {
    int id = Provider.of<NoteData>(context, listen: false).getAllNotes().length;

    Note newNote = Note(
      id: id,
      text: "",
    );

    goToNotePage(newNote, true);
  }

  void goToNotePage(Note note, bool isNewNote) {
    Navigator.push(context, MaterialPageRoute(
      builder: (context) => Editingnotepage(
        note: note,
        isNewNote: false,
      ),
    ));
  }

  void deleteNote(Note note) {
    Provider.of<NoteData>(context, listen: false).deleteNote(note);
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<NoteData>(
      builder: (context, value, child) => Scaffold(
        backgroundColor: Color(0xff006363),
        appBar: AppBar(
          backgroundColor: Color(0xff1D7373),
          title: Text(
            "Качалка",
            style: TextStyle(fontSize: 24, color: Color(0xffFFAA00)),
          ),
          centerTitle: true,
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: createNewNote,
          backgroundColor: Color(0xff1D7373),
          elevation: 0,
          child: Icon(Icons.add, color: Color(0xffFFAA00),),
        ),
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.only(left: 25, top: 10),
              child: Text(
                "Заметки",
                style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Color(0xffFFAA00)),
              ),
            ),

            value.getAllNotes().length == 0
            ? Padding(
                padding: EdgeInsets.only(top: 50),
                child:Center(
                      child: Text("Тут ничего нет...",
                      style: TextStyle(color: Colors.grey[400]),)
            )
            )
            : CupertinoListSection.insetGrouped(
                children: List.generate(
                  value.getAllNotes().length,
                      (index) => CupertinoListTile(
                        title: Text(value.getAllNotes()[index].text),
                        onTap: () => goToNotePage(value.getAllNotes()[index], false),
                        trailing: IconButton(
                          color: Color(0xffFFAA00),
                          icon: Icon(Icons.delete),
                          onPressed: () => deleteNote(value.getAllNotes()[index]),
                        ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}