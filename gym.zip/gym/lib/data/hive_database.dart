import 'package:gym/models/note.dart';
import 'package:hive/hive.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/adapters.dart';

class HiveDatabase {
  final _myBox = Hive.box("note_database1");

  List<Note> loadNotes() {
    List<Note> savedNotesFormatted = [];
    if (_myBox.get("ALL_NOTESS") != null) {
      List<dynamic> savedNotes = _myBox.get("ALL_NOTESS");
      for (int i = 0; i < savedNotes.length; i++) {
        Note individualNote = Note(
          id: savedNotes[i][0],
          text: savedNotes[i][1],
        );
        savedNotesFormatted.add(individualNote);
      }
    }
    else {
      Note(id: 0, text: "Тренировка");
      Note(id: 1, text: "Еда");
      Note(id: 2, text: "Цитаты");
      Note(id: 3, text: "Как познакомиться с девушкой");
    }

    return savedNotesFormatted;
  }

  void savedNotes(List<Note> allNotes) {
    List<List<dynamic>> allNotesFormatted = [];
    for (var note in allNotes) {
      int id = note.id;
      String text = note.text;
      allNotesFormatted.add([id, text]);
    }
    _myBox.put("ALL_NOTESS", allNotesFormatted);
  }
}

