import 'package:flutter/cupertino.dart';
import 'package:gym/data/hive_database.dart';
import 'package:gym/models/note.dart';

class NoteData extends ChangeNotifier {

  final db = HiveDatabase();

  List<Note> allNotes = [];

  void initializeNotes() {
    allNotes = db.loadNotes();
    notifyListeners();
  }

  List<Note> getAllNotes() {
    return allNotes;
  }

  void addNewNote(Note note) {
    allNotes.add(note);
    db.savedNotes(allNotes);
    notifyListeners();
  }

  void updateNote(Note note, String text){
    for (int i = 0; i < allNotes.length; i++) {
      if (allNotes[i].id == note.id){
        allNotes[i].text = text;
        break;
      }
    }
    db.savedNotes(allNotes);
    notifyListeners();
  }

  void deleteNote(Note note){
    allNotes.remove(note);
    db.savedNotes(allNotes);
    notifyListeners();
  }
}
