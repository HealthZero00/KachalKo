class Note {
  int id;
  String text;


  Note({
    required this.id,
    required this.text
});
}