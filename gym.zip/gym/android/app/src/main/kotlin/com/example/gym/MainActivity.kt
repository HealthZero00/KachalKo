package com.example.gym

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
